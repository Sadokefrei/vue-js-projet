<template>
    <h1>Register</h1>
</template>
<script setup langu="ts"></script>