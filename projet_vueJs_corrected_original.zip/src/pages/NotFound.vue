<template>
    <h1>ERROR 404</h1>
</template>
<script setup langu="ts"></script>