<template>
    <h1>Home page</h1>
</template>
<script setup langu="ts"></script>
